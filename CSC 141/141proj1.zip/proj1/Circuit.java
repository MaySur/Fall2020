import java.util.Scanner;

public class Circuit
{
public static void main(String args[])
{
Scanner keyboard = new Scanner(System.in);
System.out.print("Enter the retail price:");
double price = keyboard.nextDouble();

double profit = price * 0.4;

System.out.println("The profit earned is "+profit+".");
}
}