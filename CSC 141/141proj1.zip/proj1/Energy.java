import java.util.Scanner;

public class Energy 
{
public static void main (String args[])
{
Scanner keyboard = new Scanner(System.in);

int total = 12467;

int energy_drink = (int)(total * .14);

int preference = (int)(energy_drink*.64);

System.out.println(energy_drink + 
" customers in the survey purchased "+ 
"one or more energy drinks per week.");
System.out.println(preference + 
" customers in the survey prefer citrus-flavored "+ 
"energy drinks.");
}
}
