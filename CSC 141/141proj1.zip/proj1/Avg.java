import java.util.Scanner;

public class Avg
{
public static void main(String args[])
{
Scanner keyboard = new Scanner(System.in);
System.out.print("Enter the first test score:");
int score1 = keyboard.nextInt();
System.out.print("Enter the second test score:");
int score2 = keyboard.nextInt();
System.out.print("Enter the third test score:");
int score3 = keyboard.nextInt();

double avg = (score1+score2+score3)/3.0;

System.out.println("We have three tests: "+score1+", "
   +score2+", and "+score3+". \nThe average is "+avg+".");
}
}