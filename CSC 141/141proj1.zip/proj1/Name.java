public class Name{
public static void main(String args[])
{
String name;
int age;
double annualPay;

name = "Joe Mahoeny";
age = 26;
annualPay = 100000;
System.out.println("My name is "+name+", my age is "+age+" and");
System.out.print("I hope to earn $"+annualPay+" per year.");
}
}