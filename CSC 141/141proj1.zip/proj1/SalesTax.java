import java.util.Scanner;

public class SalesTax
{
public static void main(String args[])
{
double sale, state_tax, county_tax, sales_tax, total_sale;

Scanner keyboard = new Scanner(System.in);

System.out.print ("What is amount of the purchase? ");
sale = keyboard.nextDouble();

System.out.println ("The amount of the purchase is $" + sale + ".");

state_tax = sale * 4/100.0;
System.out.println ("The state sales tax is $" + state_tax + ".");

county_tax = sale* 2.0/100;
System.out.println ("The county sales tax is $" + county_tax + ".");

sales_tax = state_tax + county_tax;
System.out.println ("The total sales tax is $" + sales_tax + ".");

total_sale = sale + sales_tax;
System.out.println ("The total of the sale is $" + total_sale + ".");
}
}