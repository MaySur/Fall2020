import java.util.Scanner;

public class Ingredient
{
public static void main (String args[])
{
Scanner keyboard = new Scanner(System.in);

double sugar_per_cookie = 1.5/48;
double butter_per_cookie = 1/48.0;
double flour_per_cookie = 2.75/48;

System.out.print("Enter how many cookies to make:");
int num_of_cookies = keyboard.nextInt();

System.out.println("We need: \n"+
sugar_per_cookie*num_of_cookies + " cups of sugar,");
System.out.println(
butter_per_cookie*num_of_cookies + " cups of butter, and");
System.out.println(
flour_per_cookie*num_of_cookies + " cups of flour.");
}
}
