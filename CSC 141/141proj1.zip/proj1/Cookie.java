import java.util.Scanner;

public class Cookie
{
public static void main(String args[])
{
double calorie_per_cookie = 300*10/40.0;

Scanner keyboard = new Scanner(System.in);

System.out.print ("Enter the number of cookies: ");
int n = keyboard.nextInt();

System.out.println ("Total calories consumed is " + n*calorie_per_cookie + ".");
}
}