import java.util.Scanner;

public class Percentage
{
public static void main (String args[])
{
Scanner keyboard = new Scanner(System.in);

System.out.print("How many male students in class: ");
int male = keyboard.nextInt ();

System.out.print("How many female students in class: ");
int female = keyboard.nextInt ();

int total = male + female;
double percentage_of_male = (double)male/total;
double percentage_of_female = (double)female/total;

System.out.println ("The percentage of male is: "
   + percentage_of_male+ " or "+(int)(percentage_of_male*100) + "%.");
System.out.println ("The percentage of female is: "
   + percentage_of_female+ " or "+(int)(percentage_of_female*100) + "%.");

}
}
