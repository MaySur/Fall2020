import java.util.Scanner;

public class Restaurant
{
public static void main (String args[])
{
double price, tax, tip;

Scanner keyboard = new Scanner(System.in);

System.out.println ("What is the cost of the restaurant bill? ");
price = keyboard.nextDouble ();

System.out.println ("The cost of the restaurant bill is $" + price + ".");

tax = price * .0675;
System.out.println ("The tax is $" +tax+ ".");

tip = (price + tax) * .2;
System.out.println ("The tip is $" +tip+ ".");

System.out.println ("The total cost of the restaurant bill is $" +(price + tax + tip)+ ".");

}
}
