//slide 44
import java.util.*;

public class TriangleNum{
public static void main(String [] args){
   Scanner kb = new Scanner(System.in);
   int n = kb.nextInt(); // try 6
   for(int i = 1; i<=n; i++) {
      for(int j = 1; j<=i; j++)
      {
         System.out.print(i); 
         // not using println
      }
      System.out.println();
   }
}
}