//slide 42
import java.util.*;

public class HollowSquare{
public static void main(String [] args){
   Scanner kb = new Scanner(System.in);
   int n = kb.nextInt(); // try 6
   for(int i = 1; i<=n; i++) System.out.print("*");
   System.out.println(); // or println("")
   for(int i = 1; i<=n-2; i++)
   {
      System.out.print("*");
      for(int j = 1; j<=n-2; j++)
      {
         System.out.print(" "); 
         // not using println
      }
      System.out.println("*");
   }
   for(int i = 1; i<=n; i++) System.out.print("*");
   System.out.println(); // or println("")   
}
}