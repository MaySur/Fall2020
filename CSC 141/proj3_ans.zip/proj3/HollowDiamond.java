import java.util.*;

public class HollowDiamond{
public static void main(String args[]){
   Scanner kb = new Scanner(System.in);
   System.out.print("Enter row number: ");
   int R = kb.nextInt();
   for(int i = 0; i< 2*R-1; i++) // Q1
      System.out.print("$");     // first line
   System.out.println();
   for(int i = 0; i < R-1; i++){ //Q2: R-1 lines of upper part
      for(int j = 0; j<R-i-1; j++) //Q3
         System.out.print("$");
      for(int j = 0; j<2*i+1; j++) //Q4
         System.out.print(" ");
      for(int j = 0; j<R-i-1; j++) //Q5=Q3
         System.out.print("$");
      System.out.println();
      }
   for(int i = 0; i < R-2; i++){  //Q6
      for(int j = 0; j<i+2; j++)  //Q7
         System.out.print("$");
      for(int j = 0; j<2*(R-i)-5; j++) //Q8
         System.out.print(" ");
      for(int j = 0; j<i+2; j++)  //Q9=Q7
         System.out.print("$");
      System.out.println();
      }
   for(int i = 0; i< 2*R-1; i++) //Q10 = Q1
      System.out.print("$");
   System.out.println();  // bottom line
   System.out.println("Option two:");
   for(int i = 1; i<= 2*R-1; i++)
      System.out.print("$");
   System.out.println();
   for(int i = 1; i <= R-1; i++){ // or <R
      for(int j = 1; j<=R-i; j++) // or <R-i
         System.out.print("$");
      for(int j = 1; j<=2*i-1; j++) // or <2*i
         System.out.print(" ");
      for(int j = 1; j<=R-i; j++)
         System.out.print("$");
      System.out.println();
      }
   for(int i = 1; i <= R-2; i++){
      for(int j = 1; j<=i+1; j++)
         System.out.print("$");
      for(int j = 1; j<=2*(R-i)-3; j++)
         System.out.print(" ");
      for(int j = 1; j<=i+1; j++)
         System.out.print("$");
      System.out.println();
      }
   for(int i = 1; i<= 2*R-1; i++)
      System.out.print("$");
   System.out.println();
   
   System.out.println("Option three.");
   for(int i = 1; i< 2*R; i++) //TOP
      System.out.print("$");
   System.out.println();
   int k = R-1;
   for(int i = 1; i<2*(R-1);  k=(i++>R-2)?k+1:k-1){
   // conditional change of # of $s
      for(int j = 1; j<=k; j++)
         System.out.print("$");
      for(int j = 1; j<2*(R-k); j++) // j<=2(R-k)-1!
         System.out.print(" ");
      for(int j = 1; j<=k; j++)
         System.out.print("$");
      System.out.println();
   }
   for(int i = 1; i< 2*R; i++) //BOTTOM
      System.out.print("$");
   System.out.println();
}
}
