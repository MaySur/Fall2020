import java.util.*;

public class Diamond{
public static void main(String args[]){
   Scanner kb = new Scanner(System.in);
   System.out.print("Enter row number: ");
   int R = kb.nextInt();
   System.out.println("Option One.");
   for(int i = 0; i<R-1; i++) //Q1
      System.out.print(" ");
   System.out.println("$"); //Top line
   for(int i = 0; i<R-1; i++){
      for(int j = 0; j<R-i-2; j++) //Q2
         System.out.print(" ");
      System.out.print("$");
      for(int j = 0; j<2*i+1; j++) //Q3
         System.out.print(" ");
      System.out.println("$");
   }
   for(int i = 0; i<R-2; i++){
      for(int j = 0; j<i+1; j++) //Q4
         System.out.print(" ");
      System.out.print("$");
      for(int j = 0; j<2*(R-i)-5; j++) //Q5
         System.out.print(" ");
      System.out.println("$");
   }
   for(int i = 0; i<R-1; i++) //Q6
      System.out.print(" ");
   System.out.println("$"); 

   System.out.println("Option Two.");
   for(int i = 0; i<R-1; i++)
      System.out.print(" ");
   System.out.println("$");
   int k = R-2;
   for(int i = 0; i<2*R-3; k=(i>R-3)?k+1:k-1,i++){
      for(int j = 0; j<k; j++)
         System.out.print(" ");
      System.out.print("$");
      for(int j = 0; j<2*R-3-2*k; j++)
         System.out.print(" ");
      System.out.println("$");
     } 
   for(int i = 0; i<R-1; i++)
      System.out.print(" ");
   System.out.println("$");
   
}
}