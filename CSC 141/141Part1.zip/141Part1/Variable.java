public class Variable {
public static void main(String [] args){
   double i = 3;
   i = Math.sqrt(2);
   System.out.print("The value is ");
   System.out.println(i);
}
}