//   This is a simple java program

public class Simple {
public static void main(String[] args){
       System.out.println("Programming\"\'\n\t\b\r\\isgreatfun!");
       System.out.println("Programming     is    great   fun!");
       System.out.print("Programming     is    great   fun!");
       System.out.println("Programming     is    great   fun!");
}
} 