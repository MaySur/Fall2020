import javax.swing.JOptionPane;
import java.text.DecimalFormat;
public class PayrollDialog
{
	public static void main(String [] args)
	{
		String name, inputString;
		int hours;
		double payRate=0.0, grossPay=0.0;

		DecimalFormat formatter = new DecimalFormat("#0.00");

		name = 
         JOptionPane.showInputDialog
            ("What is your name?");

		inputString = 
         JOptionPane.showInputDialog
            ("How many hours did you work this week?");
      hours = Integer.parseInt(inputString);
      
		inputString = 
         JOptionPane.showInputDialog
            ("How many hours did you work this week?");
      payRate = Double.parseDouble(inputString);
      
      grossPay = hours * payRate;

		JOptionPane.showMessageDialog(null, "Hello " + 
		name + ", your gross pay is $"+formatter.format(grossPay) + ".");		


/*      System.out.println("Hello, "+name);
      System.out.println("Your gross pay is $"+grossPay);
      System.out.println("Great success!");	*/
    }
}
